#!/bin/bash
sudo cp bin/ropweaver /usr/local/bin/ropweaver
sudo chmod +x /usr/local/bin/ropweaver
echo "[+] ROPWeaver installed to /usr/local/bin/ropweaver"
