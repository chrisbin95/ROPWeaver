================================================================================
                    ROPWeaver v1.6.4 for Windows (x86_64)
            Academic Research Tool - Oxford Brookes University
                       Build Identifier: 1.6.4
================================================================================

Quick Start:
  1. Open PowerShell or Command Prompt in this folder.
  2. Run ropweaver on a target binary:
     .\ropweaver.exe samples\classic_bof.exe --list-gadgets
     .\ropweaver.exe samples\classic_bof.exe --suggest-gadgets
     .\ropweaver.exe samples\classic_bof.exe --auto-chain

Documentation & Online Explorer:
  Visit: https://ropweaver.io/ or local web explorer interface.

License & Third-Party Notices:
  ROPWeaver is licensed under the MIT License (see LICENSE).
  This distribution bundles required third-party components (including
  Capstone, libcurl, OpenSSL, zlib, and MinGW/GCC runtimes).
  See THIRD_PARTY_NOTICES.txt for complete upstream notices and licenses.
