================================================================================
                    ROPWeaver v1.2.4 for macOS (x86_64)
            Academic Research Tool - Oxford Brookes University
                        Build Identifier: 6e110c2
================================================================================

Requirements:
  macOS 11.0+ (Sonoma, Ventura, Monterey, Big Sur)
  Homebrew packages: brew install capstone curl

Quick Start:
  ./bin/ropweaver <target_binary> --list-gadgets
  ./bin/ropweaver <target_binary> --suggest-gadgets
  ./bin/ropweaver <target_binary> --auto-chain

Installed Execution:
  Run ./install.sh to verify Homebrew dependencies and link ropweaver into PATH.
