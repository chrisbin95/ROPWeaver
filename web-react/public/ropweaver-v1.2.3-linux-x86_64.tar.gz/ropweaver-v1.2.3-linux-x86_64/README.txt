ROPWeaver v1.2.3 Linux x86_64 Release
==================================================
Installation:
  sudo cp bin/ropweaver /usr/local/bin/
  # Or run ./install.sh

Usage:
  ropweaver <binary_path> --depth 5
  ropweaver <binary_path> --auto-chain --upload-report
