#!/bin/bash
set -e
echo "[+] Installing ROPWeaver v1.2.3 to /usr/local/bin..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
sudo cp "$SCRIPT_DIR/bin/ropweaver" /usr/local/bin/ropweaver
sudo chmod +x /usr/local/bin/ropweaver
echo "[+] Done! Run 'ropweaver --help' to get started."
