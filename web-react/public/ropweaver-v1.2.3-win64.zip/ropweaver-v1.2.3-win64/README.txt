ROPWeaver v1.2.3 Portable Windows Release
==================================================
Usage:
  .\ropweaver.exe <binary_path> [options]

Examples:
  .\ropweaver.exe samples\test --depth 5 --raw
  .\ropweaver.exe samples\test --auto-chain --upload-report
  .\ropweaver.exe --suggest-gadgets

Requirements:
  Windows 10 / 11 64-bit (x86_64)
  Bundled DLLs must remain in the same directory as ropweaver.exe
